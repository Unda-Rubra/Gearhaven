#version 120

#define OVERWORLD_SHADER

#define WORLD
#define ENTITIES
#define BLOCKENTITIES

#include "/dimensions/clrwl_solid.vsh"
