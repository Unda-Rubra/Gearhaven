#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_END
#define PROGRAM_GBUFFERS_DAMAGEDBLOCK
#define vsh
#include "/program/clrwl_damagedblock.vsh"
