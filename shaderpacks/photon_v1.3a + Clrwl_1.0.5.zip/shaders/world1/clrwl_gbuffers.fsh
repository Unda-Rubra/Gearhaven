#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_END
#define PROGRAM_GBUFFERS_TERRAIN
#define PROGRAM_GBUFFERS_BLOCK
#define PROGRAM_GBUFFERS_ENTITIES
#define fsh
#include "/program/clrwl_solid.fsh"
