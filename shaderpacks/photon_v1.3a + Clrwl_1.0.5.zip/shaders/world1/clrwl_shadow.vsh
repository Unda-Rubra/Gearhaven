#version 400 compatibility
#extension GL_ARB_shader_image_load_store : enable
#define IS_COLORWHEEL
#define WORLD_END
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define PROGRAM_SHADOW_BLOCK
#define vsh
#include "/program/clrwl_shadow.vsh"
