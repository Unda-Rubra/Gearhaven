#version 400 compatibility
#define IS_COLORWHEEL
#define WORLD_OVERWORLD
#define PROGRAM_SHADOW
#define PROGRAM_SHADOW_SOLID
#define PROGRAM_SHADOW_BLOCK
#define fsh
#include "/program/clrwl_shadow.fsh"
